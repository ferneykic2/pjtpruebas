-- --------------------------------------------------------
-- Host:                         ec2-3-88-213-143.compute-1.amazonaws.com
-- Versión del servidor:         5.7.19-log - MySQL Community Server (GPL)
-- SO del servidor:              Win32
-- HeidiSQL Versión:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para bdpruebas
CREATE DATABASE IF NOT EXISTS `bdpruebas` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `bdpruebas`;

-- Volcando estructura para tabla bdpruebas.cliente
CREATE TABLE IF NOT EXISTS `cliente` (
  `IDCLIENTE` int(11) NOT NULL AUTO_INCREMENT,
  `NUMID` varchar(15) NOT NULL,
  `NOMBRE` varchar(256) NOT NULL,
  `TELEFONO` varchar(15) NOT NULL,
  `DIRECCION` varchar(200) NOT NULL,
  PRIMARY KEY (`IDCLIENTE`) USING BTREE,
  UNIQUE KEY `IDX_NUMID` (`NUMID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla bdpruebas.consecutivo
CREATE TABLE IF NOT EXISTS `consecutivo` (
  `CODDOC` varchar(6) NOT NULL,
  `CONSEC` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`CODDOC`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla bdpruebas.factura
CREATE TABLE IF NOT EXISTS `factura` (
  `IDFACTURA` int(11) NOT NULL AUTO_INCREMENT,
  `NUMFACTURA` varchar(12) NOT NULL,
  `FECHA` date NOT NULL,
  `IDCLIENTE` int(11) NOT NULL,
  `TOTAL` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDFACTURA`) USING BTREE,
  UNIQUE KEY `IDX_FACTURA` (`NUMFACTURA`) USING BTREE,
  KEY `FK_FACT_CLIENTE` (`IDCLIENTE`),
  CONSTRAINT `FK_FACT_CLIENTE` FOREIGN KEY (`IDCLIENTE`) REFERENCES `cliente` (`IDCLIENTE`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla bdpruebas.facturadet
CREATE TABLE IF NOT EXISTS `facturadet` (
  `IDFACTURADET` int(11) NOT NULL AUTO_INCREMENT,
  `IDFACTURA` int(11) NOT NULL,
  `IDPRODUCTO` int(11) NOT NULL,
  `CODPRODUCTO` varchar(15) NOT NULL DEFAULT '',
  `DESCRIPCION` varchar(200) NOT NULL DEFAULT '',
  `CANTIDAD` double NOT NULL DEFAULT '1',
  `VALOR` double NOT NULL DEFAULT '0',
  `TOTAL` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDFACTURADET`) USING BTREE,
  KEY `FK_FACTDET_FACT` (`IDFACTURA`),
  KEY `FK_FACTDET_PRODUCTO` (`IDPRODUCTO`),
  CONSTRAINT `FK_FACTDET_FACT` FOREIGN KEY (`IDFACTURA`) REFERENCES `factura` (`IDFACTURA`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_FACTDET_PRODUCTO` FOREIGN KEY (`IDPRODUCTO`) REFERENCES `producto` (`IDPRODUCTO`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla bdpruebas.producto
CREATE TABLE IF NOT EXISTS `producto` (
  `IDPRODUCTO` int(11) NOT NULL AUTO_INCREMENT,
  `CODPRODUCTO` varchar(15) NOT NULL,
  `DESCRIPCION` varchar(200) NOT NULL,
  `VALOR` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDPRODUCTO`) USING BTREE,
  UNIQUE KEY `IDX_CODPRODUCTO` (`CODPRODUCTO`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=447 DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
